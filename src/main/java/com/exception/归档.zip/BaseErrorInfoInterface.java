package com.exception;

/**
 * @Classname: BaseErrorInfoInterface
 * @Date: 16/11/2021 8:50 下午
 * @Author: garlam
 * @Description:
 */
public interface BaseErrorInfoInterface {

    /**
     *  错误码
     * @return
     */
    String getResultCode();

    /**
     * 错误描述
     * @return
     */
    String getResultMsg();
}
