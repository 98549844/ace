package com.entity.dao.hibernate;

import com.entity.dao.base.baseEntity;

import java.io.Serializable;

//table name : persistent_logins
public class PersistentLogins extends baseEntity implements Serializable {
}
