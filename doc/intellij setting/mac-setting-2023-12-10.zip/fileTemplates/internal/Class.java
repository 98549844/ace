#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import com.ace.controller.common.CommonController;


#parse("File Header.java")




public class ${NAME} extends CommonController{
    private static final Logger log = LogManager.getLogger(${NAME}.class.getName());


}

