#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

#parse("File Header.java")




public class ${NAME} {
    private static Logger log = LogManager.getLogger(${NAME}.class.getName());


}

